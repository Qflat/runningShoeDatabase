from django.apps import AppConfig


class MeetdeveloperConfig(AppConfig):
    name = 'meetDeveloper'
